'''
Created on Nov 20, 2012

@author: ajju
'''

import TurtlePlugin

if __name__ == '__main__':
    TurtlePlugin.start('plugin.video.filmibynature')
