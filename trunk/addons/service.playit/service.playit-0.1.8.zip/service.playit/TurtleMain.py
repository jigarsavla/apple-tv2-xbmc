'''
Created on Dec 27, 2011

@author: ajju
'''

import TurtleService

if __name__ == '__main__':
    TurtleService.start('service.playit', 'PlayIt', '/PlayIt', 8181, [8100, 8199])
