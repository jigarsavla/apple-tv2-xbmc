'''
Created on Dec 27, 2011

@author: ajju
'''

import TurtlePlugin

if __name__ == '__main__':
    TurtlePlugin.start('plugin.video.TVonDesiZone')
